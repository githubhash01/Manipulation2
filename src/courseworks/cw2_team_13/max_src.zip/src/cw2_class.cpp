/* feel free to change any part of this file, or delete this file. In general,
you can do whatever you want with this template code, including deleting it all
and starting from scratch. The only requirment is to make sure your entire
solution is contained within the cw2_team_<your_team_number> package */

#include <cw2_class.h>

#include <cmath>
#include <utility>
#include <algorithm>
#include <chrono>
#include <thread>

cw2::cw2(const rclcpp::Node::SharedPtr &node)
: node_(node),
  tf_buffer_(node->get_clock()),
  tf_listener_(tf_buffer_),
  g_cloud_ptr(new PointC)
{
  t1_service_ = node_->create_service<cw2_world_spawner::srv::Task1Service>(
    "/task1_start",
    std::bind(&cw2::t1_callback, this, std::placeholders::_1, std::placeholders::_2));
  t2_service_ = node_->create_service<cw2_world_spawner::srv::Task2Service>(
    "/task2_start",
    std::bind(&cw2::t2_callback, this, std::placeholders::_1, std::placeholders::_2));
  t3_service_ = node_->create_service<cw2_world_spawner::srv::Task3Service>(
    "/task3_start",
    std::bind(&cw2::t3_callback, this, std::placeholders::_1, std::placeholders::_2));

  pointcloud_topic_ = node_->declare_parameter<std::string>(
    "pointcloud_topic", "/r200/camera/depth_registered/points");
  pointcloud_qos_reliable_ =
    node_->declare_parameter<bool>("pointcloud_qos_reliable", true);

  pointcloud_callback_group_ =
    node_->create_callback_group(rclcpp::CallbackGroupType::Reentrant);
  rclcpp::SubscriptionOptions pointcloud_sub_options;
  pointcloud_sub_options.callback_group = pointcloud_callback_group_;

  rclcpp::QoS pointcloud_qos = rclcpp::SensorDataQoS();
  if (pointcloud_qos_reliable_) {
    pointcloud_qos = rclcpp::QoS(rclcpp::KeepLast(1)).reliable().durability_volatile();
  }

  // Subscribe with BOTH reliable and best-effort QoS.
  auto reliable_qos = rclcpp::QoS(rclcpp::KeepLast(1)).reliable().durability_volatile();
  auto besteffort_qos = rclcpp::SensorDataQoS();

  color_cloud_sub_ = node_->create_subscription<sensor_msgs::msg::PointCloud2>(
      pointcloud_topic_, reliable_qos,
      std::bind(&cw2::cloud_callback, this, std::placeholders::_1),
      pointcloud_sub_options);

  color_cloud_sub_besteffort_ = node_->create_subscription<sensor_msgs::msg::PointCloud2>(
      pointcloud_topic_, besteffort_qos,
      std::bind(&cw2::cloud_callback, this, std::placeholders::_1),
      pointcloud_sub_options);

  arm_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(node_, "panda_arm");
  hand_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(node_, "hand");

  arm_group_->setPlanningTime(10.0);
  arm_group_->setNumPlanningAttempts(5);
  arm_group_->setMaxVelocityScalingFactor(0.5);
  arm_group_->setMaxAccelerationScalingFactor(0.5);

  RCLCPP_INFO(
    node_->get_logger(),
    "cw2_team_x template initialised with pointcloud topic '%s' (%s QoS)",
    pointcloud_topic_.c_str(),
    pointcloud_qos_reliable_ ? "reliable" : "sensor-data");
}

void cw2::cloud_callback(const sensor_msgs::msg::PointCloud2::ConstSharedPtr msg)
{
  pcl::PCLPointCloud2 pcl_cloud;
  pcl_conversions::toPCL(*msg, pcl_cloud);

  PointCPtr latest_cloud(new PointC);
  pcl::fromPCLPointCloud2(pcl_cloud, *latest_cloud);

  std::lock_guard<std::mutex> lock(cloud_mutex_);
  g_input_pc_frame_id_ = msg->header.frame_id;
  g_cloud_ptr = std::move(latest_cloud);
  ++g_cloud_sequence_;
}


// Helper: move the arm so the camera looks down at a target point
 
bool cw2::move_arm_above(const geometry_msgs::msg::Point &target,
                         double height)
{
  geometry_msgs::msg::Pose pose;
  pose.position.x = target.x;
  pose.position.y = target.y;
  pose.position.z = target.z + height;
 
  // look straight down at the table
  pose.orientation.x = 1.0;
  pose.orientation.y = 0.0;
  pose.orientation.z = 0.0;
  pose.orientation.w = 0.0;
 
  arm_group_->setPoseTarget(pose);
 
  moveit::planning_interface::MoveGroupInterface::Plan plan;
  bool plan_ok =
    (arm_group_->plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);
 
  if (!plan_ok) {
    RCLCPP_WARN(node_->get_logger(), "Planning failed, retrying with higher z");
    // Try a bit higher if planning fails
    pose.position.z += 0.1;
    arm_group_->setPoseTarget(pose);
    plan_ok =
      (arm_group_->plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);
    if (!plan_ok) {
      RCLCPP_ERROR(node_->get_logger(), "Planning failed on retry");
      return false;
    }
  }
 
  auto exec_result = arm_group_->execute(plan);
  if (exec_result != moveit::core::MoveItErrorCode::SUCCESS) {
    RCLCPP_ERROR(node_->get_logger(), "Execution failed");
    return false;
  }
 
  // Wait a moment for the camera to settle and new cloud to arrive
  std::this_thread::sleep_for(std::chrono::milliseconds(1500));
 
  RCLCPP_INFO(node_->get_logger(), "Arm move succeeded");
  return true;
}
 
// Helper: get the latest cloud, transformed into panda_link0 frame
 
PointCPtr cw2::get_transformed_cloud()
{
  const int max_attempts = 5;
  const std::string target_frame = "panda_link0";
 
  for (int attempt = 1; attempt <= max_attempts; ++attempt) {
 
    // Record current sequence and wait for a new frame
    std::uint64_t target_seq;
    {
      std::lock_guard<std::mutex> lock(cloud_mutex_);
      target_seq = g_cloud_sequence_ + 1;
    }
 
    // Wait up to 5 seconds for a new cloud
    for (int i = 0; i < 50; ++i) {
      {
        std::lock_guard<std::mutex> lock(cloud_mutex_);
        if (g_cloud_sequence_ >= target_seq) break;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
 
    // Grab a copy of the cloud and its frame
    PointCPtr cloud_copy(new PointC);
    std::string source_frame;
    {
      std::lock_guard<std::mutex> lock(cloud_mutex_);
      if (!g_cloud_ptr || g_cloud_ptr->empty()) {
        RCLCPP_WARN(node_->get_logger(),
          "Cloud is empty on attempt %d/%d, retrying...",
          attempt, max_attempts);
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        continue;
      }
      *cloud_copy = *g_cloud_ptr;
      source_frame = g_input_pc_frame_id_;
    }
 
    // Transform to panda_link0 if needed
    if (source_frame != target_frame) {
      try {
        auto transform = tf_buffer_.lookupTransform(
          target_frame, source_frame, tf2::TimePointZero,
          tf2::durationFromSec(2.0));
 
        PointCPtr transformed(new PointC);
        pcl_ros::transformPointCloud(*cloud_copy, *transformed, transform);
        transformed->header.frame_id = target_frame;
 
        RCLCPP_INFO(node_->get_logger(),
          "Transformed cloud to '%s' (%zu points)",
          target_frame.c_str(), transformed->size());
        return transformed;
 
      } catch (const tf2::TransformException &ex) {
        RCLCPP_ERROR(node_->get_logger(),
          "TF transform failed on attempt %d: %s", attempt, ex.what());
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        continue;
      }
    }
 
    return cloud_copy;
  }
 
  RCLCPP_ERROR(node_->get_logger(),
    "Failed to get a valid cloud after %d attempts", max_attempts);
  return PointCPtr(new PointC);
}
 
// Helper: crop a cloud in XY around a centre point
 
PointCPtr cw2::crop_cloud_xy(PointCPtr cloud,
                             const geometry_msgs::msg::Point &centre,
                             double half_size)
{
  PointCPtr after_x(new PointC);
  pcl::PassThrough<PointT> pass;
 
  pass.setInputCloud(cloud);
  pass.setFilterFieldName("x");
  pass.setFilterLimits(centre.x - half_size, centre.x + half_size);
  pass.filter(*after_x);
 
  PointCPtr after_xy(new PointC);
  pass.setInputCloud(after_x);
  pass.setFilterFieldName("y");
  pass.setFilterLimits(centre.y - half_size, centre.y + half_size);
  pass.filter(*after_xy);
 
  RCLCPP_INFO(node_->get_logger(),
    "Cropped XY around (%.3f, %.3f) ±%.3f: %zu -> %zu points",
    centre.x, centre.y, half_size,
    cloud->size(), after_xy->size());
 
  return after_xy;
}
 
// Helper: remove green ground-tile points, keeping only the shape
 
PointCPtr cw2::filter_out_ground_color(PointCPtr cloud)
{
  PointCPtr filtered(new PointC);
  filtered->points.reserve(cloud->size());
 
  for (const auto &pt : cloud->points) {
    // Extract RGB from the RGBA field
    uint8_t r = pt.r;
    uint8_t g = pt.g;
    uint8_t b = pt.b;
 
    // Skip points that are ground tiles (green)
    bool is_green = (g > 80) && (g > r + 20) && (g > b + 20);
    bool is_dark  = (r < 30 && g < 30 && b < 30);
    bool is_white = (r > 220 && g > 220 && b > 220);
 
    if (!is_green && !is_dark && !is_white) {
      filtered->points.push_back(pt);
    }
  }
 
  filtered->width = filtered->points.size();
  filtered->height = 1;
  filtered->is_dense = true;
 
  RCLCPP_INFO(node_->get_logger(),
    "Color filter (removed green/dark/white): %zu -> %zu points",
    cloud->size(), filtered->size());
 
  return filtered;
}

// Strategy: a cross has material through its centre; a nought has a hole.
// We compare the density of points in the inner region vs the overall shape.

std::string cw2::classify_shape(PointCPtr shape_cloud,
                                const geometry_msgs::msg::Point &centre)
{
  if (shape_cloud->empty()) {
    RCLCPP_WARN(node_->get_logger(), "Empty shape cloud, defaulting to cross");
    return "cross";
  }
 
  // We count points within a small radius of the centre vs the whole shape.
 
  double inner_radius = 0.015;   // 15mm – well inside the centre cell
  double outer_radius = 0.08;    // 80mm – covers most of the shape
 
  int inner_count = 0;
  int outer_count = 0;
 
  for (const auto &pt : shape_cloud->points) {
    double dx = pt.x - centre.x;
    double dy = pt.y - centre.y;
    double dist = std::sqrt(dx * dx + dy * dy);
 
    if (dist < inner_radius) {
      inner_count++;
    }
    if (dist < outer_radius) {
      outer_count++;
    }
  }
 
  double ratio = (outer_count > 0)
    ? static_cast<double>(inner_count) / outer_count
    : 0.0;
 
  RCLCPP_INFO(node_->get_logger(),
    "Shape classification: inner=%d, outer=%d, ratio=%.4f",
    inner_count, outer_count, ratio);
 
  // A cross will have a meaningful proportion of points in the centre.
  double threshold = 0.005;
 
  if (ratio > threshold) {
    RCLCPP_INFO(node_->get_logger(), "Classified as: CROSS");
    return "cross";
  } else {
    RCLCPP_INFO(node_->get_logger(), "Classified as: NOUGHT");
    return "nought";
  }
}


void cw2::t1_callback(
  const std::shared_ptr<cw2_world_spawner::srv::Task1Service::Request> request,
  std::shared_ptr<cw2_world_spawner::srv::Task1Service::Response> response)
{
  (void)request;
  (void)response;

  std::string frame_id;
  std::size_t point_count = 0;
  std::uint64_t sequence = 0;
  {
    std::lock_guard<std::mutex> lock(cloud_mutex_);
    frame_id = g_input_pc_frame_id_;
    point_count = g_cloud_ptr ? g_cloud_ptr->size() : 0;
    sequence = g_cloud_sequence_;
  }

  RCLCPP_WARN(
    node_->get_logger(),
    "Task 1 is not implemented in cw2_team_x. Latest cloud: seq=%llu frame='%s' points=%zu",
    static_cast<unsigned long long>(sequence),
    frame_id.c_str(),
    point_count);
}


void cw2::t2_callback(
  const std::shared_ptr<cw2_world_spawner::srv::Task2Service::Request> request,
  std::shared_ptr<cw2_world_spawner::srv::Task2Service::Response> response)
{
  // Wait until the camera is publishing point clouds
  
  RCLCPP_INFO(node_->get_logger(),
    "Waiting for point cloud data from camera...");
 
  // Wait up to 30 seconds for the first cloud to arrive
  for (int i = 0; i < 300; ++i) {
    {
      std::lock_guard<std::mutex> lock(cloud_mutex_);
      if (g_cloud_sequence_ > 0 && g_cloud_ptr && !g_cloud_ptr->empty()) {
        RCLCPP_INFO(node_->get_logger(),
          "Camera is publishing (seq=%llu, %zu points). Proceeding.",
          static_cast<unsigned long long>(g_cloud_sequence_),
          g_cloud_ptr->size());
        break;
      }
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
 
  // Move to a safe starting position
  RCLCPP_INFO(node_->get_logger(), "Moving to ready position...");
  arm_group_->setNamedTarget("ready");
  arm_group_->move();
  std::this_thread::sleep_for(std::chrono::milliseconds(2000));

  // Height above the shape point to position the camera
  double camera_height = 0.60;
 
  // Half-size of the XY crop box with extra margin
  double crop_half = 0.13;
 
  std::vector<std::string> ref_types;
 
  for (size_t i = 0; i < request->ref_object_points.size(); ++i) {
    const auto &ref_pt = request->ref_object_points[i].point;
 
    RCLCPP_INFO(node_->get_logger(),
      "-- Inspecting reference %zu at (%.3f, %.3f, %.3f)",
      i + 1, ref_pt.x, ref_pt.y, ref_pt.z);
 
    // Move camera above
    if (!move_arm_above(ref_pt, camera_height)) {
      RCLCPP_ERROR(node_->get_logger(),
        "Failed to move above reference %zu", i + 1);
      ref_types.push_back("unknown");
      continue;
    }
 
    // Get the transformed cloud
    PointCPtr full_cloud = get_transformed_cloud();
    PointCPtr xy_cropped = crop_cloud_xy(full_cloud, ref_pt, crop_half);
    PointCPtr shape_cloud = filter_out_ground_color(xy_cropped);
 
    // Classify
    std::string shape_type = classify_shape(shape_cloud, ref_pt);
    ref_types.push_back(shape_type);
 
    RCLCPP_INFO(node_->get_logger(),
      "Reference %zu classified as: %s", i + 1, shape_type.c_str());
  }
 
  // classify mystery shape
  const auto &mystery_pt = request->mystery_object_point.point;
 
  RCLCPP_INFO(node_->get_logger(),
    "-- Inspecting mystery shape at (%.3f, %.3f, %.3f)",
    mystery_pt.x, mystery_pt.y, mystery_pt.z);
 
  if (!move_arm_above(mystery_pt, camera_height)) {
    RCLCPP_ERROR(node_->get_logger(), "Failed to move above mystery shape");
    response->mystery_object_num = 1;  // fallback guess
    return;
  }
 
  PointCPtr mystery_full = get_transformed_cloud();
  PointCPtr mystery_xy   = crop_cloud_xy(mystery_full, mystery_pt, crop_half);
  PointCPtr mystery_cloud = filter_out_ground_color(mystery_xy);
 
  std::string mystery_type = classify_shape(mystery_cloud, mystery_pt);
 
  RCLCPP_INFO(node_->get_logger(),
    "Mystery shape classified as: %s", mystery_type.c_str());
 
  // match mystery to reference
  if (ref_types.size() >= 2 && mystery_type == ref_types[0]) {
    response->mystery_object_num = 1;
  } else {
    response->mystery_object_num = 2;
  }
 
  RCLCPP_INFO(node_->get_logger(),
    "===== TASK 2 RESULT: mystery matches reference %ld =====",
    response->mystery_object_num);
}


void cw2::t3_callback(
  const std::shared_ptr<cw2_world_spawner::srv::Task3Service::Request> request,
  std::shared_ptr<cw2_world_spawner::srv::Task3Service::Response> response)
{
  (void)request;
  response->total_num_shapes = 0;
  response->num_most_common_shape = 0;
  response->most_common_shape_vector.clear();

  std::string frame_id;
  std::size_t point_count = 0;
  std::uint64_t sequence = 0;
  {
    std::lock_guard<std::mutex> lock(cloud_mutex_);
    frame_id = g_input_pc_frame_id_;
    point_count = g_cloud_ptr ? g_cloud_ptr->size() : 0;
    sequence = g_cloud_sequence_;
  }

  RCLCPP_WARN(
    node_->get_logger(),
    "Task 3 is not implemented in cw2_team_x. Latest cloud: seq=%llu frame='%s' points=%zu",
    static_cast<unsigned long long>(sequence),
    frame_id.c_str(),
    point_count);
}
